// NIM/Nama		: Bilhaq Avi Dewantara
// Nama file	: TP1_120140141_02.cpp
// Tanggal		: 06 November 2020
// Deskripsi	: Tugas 2

#include <iostream>
using namespace std;

(main){
	int satu, dua, tiga, max;
	
	cout <<"Input nilai 1 = "; cin >> satu;
	cout <<"Input nilai 2 = "; cin >> dua;
	cout <<"Input nilai 3 = "; cin >> tiga;
	
	if (satu > dua && satu > tiga){
		cout <<"\nNilai Terbesar : " << satu << endl;
	} else if ( dua > satu && dua > tiga){
		cout <<"\nNilai Terbesar : " << dua << endl;
	} else if ( tiga > satu && tiga > dua){
		cout << "\nNilai Terbesar ; " << tiga << endl;
	} else 

	
	return 0;
}

