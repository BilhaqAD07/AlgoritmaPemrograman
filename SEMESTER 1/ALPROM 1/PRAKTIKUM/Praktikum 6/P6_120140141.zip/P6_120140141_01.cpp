/*
============================================
NIM/Nama	: 120140141/Bilhaq Avi Dewantara
Nama file	: P6_120140141_
Tanggal		: 02 Desember 2020
Deskripsi	:
============================================
*/

#include <iostream>
using namespace std;

int X (int p, int q){
     return p*q;
}

int main(){
    

     int n,i;
     cin>>n;
     int bil[n];
     
     for(i=0;i<=n;i++){
     	cin>>bil[i];
	}  
	   	cout<< X(n,i);

     return 0;
}
