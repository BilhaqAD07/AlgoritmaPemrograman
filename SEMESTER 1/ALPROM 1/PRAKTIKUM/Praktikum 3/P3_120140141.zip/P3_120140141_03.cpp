/*
============================================
NIM/Nama	: 120140141/Bilhaq Avi Dewantara
Nama file	: P3_120140141_Palindrom
Tanggal		: 14 November 2020
Deskripsi	: Program Palindrom
============================================
*/

#include <iostream>
using namespace std;

int main ()
{
	int n;
	cin >> n;
	int i=0;
	
	while (i<n){
		cout << i; 
		i++;
	}
	while (i>0){
		cout << i-1;
		i--;
	}
}

