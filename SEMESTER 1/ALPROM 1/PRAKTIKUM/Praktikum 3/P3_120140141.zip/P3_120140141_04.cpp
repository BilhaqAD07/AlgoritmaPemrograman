/*
============================================
NIM/Nama	: 120140141/Bilhaq Avi Dewantara
Nama file	: P3_120140141_SoN
Tanggal		: 14 November 2020
Deskripsi	: SoN
============================================
*/

#include <iostream>
using namespace std;

int main ()
{
	int x,y;
	
	cin>>x;
	cin>>y;
	for(int i=x;i<=y;i++){
		cout << i << " ";
	}
}

